<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Guardians;
use Illuminate\Http\Request;

class GuardianController extends Controller
{
    public function guardian()
    {
        $guardian = Guardians::all();
        return view('guardian', [
            'title' => 'Guardian',
            'guardian' => $guardian,
        ]);
    }

    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
